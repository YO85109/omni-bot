# OmniBot - all deobfuscators in one Discord bot

`/deobf` (or `.deobf`) takes a script (attachment, reply, or URL), figures out which obfuscator made it,
and runs the matching tool. Every tool runs as a separate subprocess with a timeout, CPU/memory/file
limits and **no access to your bot token** (the environment is scrubbed).

| key | tool | type |
|---|---|---|
| clyde | Clyde V2-V6 | static (Node) |
| prometheus | Prometheus (+ WeAreDevs fork) | static (Node) |
| ironveil | Ironveil V1 | static (Node) |
| hercules | Hercules | static (Python) |
| moonsec | MoonSec V3 | static (.NET) -> Lua 5.1 bytecode |
| 77fuscator | 77fuscator 0.6.x | static (.NET) -> Lua 5.1 bytecode |
| ironbrew2 | IronBrew 2 | static (.NET) -> Lua 5.1 bytecode |
| luraph | Luraph v15 | **executes input in a Luau sandbox** |
| moonveil | Moonveil | **sandboxed**, two-step: `/moonveil` then `/trace` |
| centurion | Centurion v6/6.1 | **sandboxed**, disabled until `CENT_SANDBOX` is provided |

Commands: `/deobf [file|url] [tool]`, `/tools`, `/moonveil`, `/trace`, `/moonveil_reset`, and prefix `.deobf [tool]`, `.tools`, `.mv`.

## Run it
1. https://discord.com/developers/applications -> New Application -> Bot -> **Reset Token** -> enable **Message Content Intent**.
2. Invite URL scopes: `bot` + `applications.commands`; permissions: Send Messages, Attach Files, Embed Links, Read Message History.
3. On the server:
   ```bash
   cp .env.example .env      # paste the token, set OWNER_IDS and ALLOWED_GUILDS
   docker compose up -d --build
   docker compose logs -f    # shows which tools are "ready"
   ```
   Without Docker: Python 3.11+, Node 18+, .NET 9 SDK, the Luau CLI on PATH, `pip install -r requirements.txt`,
   build the two C# tools (see Dockerfile), then `python bot.py`.

## Hosting
Needs a normal Linux box, not a "bot host": about **2 vCPU / 4 GB RAM / 20 GB disk, x86_64, Docker**.
- Any VPS works: Hetzner, DigitalOcean, Vultr, Linode/Akamai, OVH, Contabo (check current prices).
- Home PC / spare machine works too (keep it on a separate network/VM, see below).
- Oracle Cloud free ARM works only if you build Luau for arm64 yourself (the Dockerfile fetches the x86_64 build).
- Avoid Replit/Glitch/Heroku-style hosts, serverless, and Pterodactyl Discord-bot hosts: tiny RAM, sleeping,
  and you usually cannot install .NET + Luau.

**Security:** Luraph/Moonveil/Centurion run the *obfuscated script's own code* in Luau. Treat the host as
disposable: dedicated VPS, no other secrets on it, keep `ALLOWED_GUILDS` set, optionally `SANDBOX_PREFIX="unshare -rn"`
to cut network access for every tool, or `ALLOW_SANDBOXED=0` to disable those three.

## Not included / known gaps
- `promdeobf.zip` was a RAR archive, so it was not added. Re-zip it as .zip (or drop its folder in `tools/promdeobf`) and register it in `omni/registry.py`.
- Centurion needs the `sandbox-copy-luraph` folder from its author (not in your upload).
- MoonSec/77fuscator/IronBrew2 produce Lua 5.1 **bytecode**. Set `UNLUAC_JAR` (+ build with `--build-arg WITH_JAVA=1`) to also return decompiled source.
- The original IronBrew2 bot sent bytecode to a third-party API (`oracle.mshq.dev`) with an API key; that was left out on purpose.
