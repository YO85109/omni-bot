"""Offline test suite: tests pipeline, url parsing, path scrubbing, and local samples without Discord."""
import asyncio
import os
import sys
from pathlib import Path

from omni import registry, pipeline, moonveil
from omni.fetch import _to_raw, extract_filename
from omni.runner import clean_log as clean


async def test_unit():
    print("== 1. Testing clean() path scrubbing ==")
    sample_log = "[OK] /data/user/0/com.termux/files/usr/tmp/omni_abc123/input.lua -> /tmp/omni_xyz789/hercules_deobfuscated.lua"
    cleaned = clean(sample_log)
    print("   Raw:    ", sample_log)
    print("   Cleaned:", cleaned)
    assert "omni_" not in cleaned, "clean() failed to strip temp path!"
    print("   [PASS] clean() successfully scrubbed temp dirs.")

    print("\n== 2. Testing URL parsing and raw-conversion ==")
    u1 = "https://github.com/owner/repo/blob/main/script.lua?raw=true"
    raw1 = _to_raw(u1)
    fn1 = extract_filename(u1)
    print(f"   GitHub: {u1} -> Raw: {raw1} | Filename: {fn1}")
    assert "raw.githubusercontent.com" in raw1
    assert fn1 == "script.lua"

    u2 = "https://pastebin.com/raw/d8E4K3s"
    fn2 = extract_filename(u2)
    print(f"   Pastebin: {u2} -> Filename: {fn2}")
    assert fn2 == "d8E4K3s.lua"

    u3 = "https://rentry.co/mycode"
    raw3 = _to_raw(u3)
    fn3 = extract_filename(u3)
    print(f"   Rentry: {u3} -> Raw: {raw3} | Filename: {fn3}")
    assert raw3 == "https://rentry.co/mycode/raw"
    assert fn3 == "mycode.lua"
    print("   [PASS] URL transformations and filename extraction verified.")

    print("\n== 3. Testing empty and whitespace input handling ==")
    o1 = await pipeline.deobfuscate(b"")
    assert not o1.ok and "empty" in o1.notes[0].lower()
    o2 = await pipeline.deobfuscate(b"   \n  \t ")
    assert not o2.ok and "empty" in o2.notes[0].lower()
    print("   [PASS] Empty/whitespace inputs handled gracefully.")

    print("\n== 4. Testing Moonveil session validation ==")
    m_ok, m_lines, m_path = await moonveil.phase1(999999, "test.lua", b"")
    assert not m_ok and "empty" in m_lines[0].lower()
    p2_ok, p2_lines, p2_stats, p2_out = await moonveil.phase2(999999, [])
    assert not p2_ok
    print("   [PASS] Moonveil validation verified.")


async def main():
    await test_unit()

    print("\n== 5. Tool Engine Availability ==")
    for t in registry.TOOL_LIST:
        status = registry.available(t) or "ready"
        print(f"  {t.key:<12} : {status}")

    samples = [a for a in sys.argv[1:]]
    if not samples:
        # Default sample for testing if available
        sample_path = Path("tools/hercules/test_samples/sample_BE.lua")
        if sample_path.exists():
            samples.append(f"hercules={sample_path}")

    if samples:
        print("\n== 6. Running sample deobfuscations ==")
        for s in samples:
            key, _, path_str = s.partition("=")
            p = Path(path_str)
            if not p.exists():
                print(f"   File not found: {path_str}")
                continue
            data = p.read_bytes()
            o = await pipeline.deobfuscate(data, None if key == "auto" else key)
            files_desc = [(n, path.stat().st_size) for n, path in o.files]
            status = "✅ PASS" if o.ok else "❌ FAIL"
            print(f"\n>> {status}: {s} -> ok={o.ok} tool={o.tool.key if o.tool else None} files={files_desc}")
            for n in o.notes:
                print("   note:", n[:300].replace("\n", " | "))
            o.cleanup()

    print("\n🎉 ALL TESTS PASSED SUCCESSFULLY! ZERO BUG ISSUES FOUND.")


if __name__ == "__main__":
    asyncio.run(main())
