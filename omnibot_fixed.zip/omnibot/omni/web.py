"""Embedded web dashboard & keep-alive server for OmniBot.

Provides:
  * Port 7860 web server (compatible with Hugging Face Spaces, Render, Koyeb, VPS)
  * Live health check (/health) for 24/7 keep-alive pingers (UptimeRobot, cron-job)
  * Real-time metrics API (/api/status)
  * Web-based deobfuscator interface (/api/deobfuscate)
  * Full responsive dark-themed dashboard
"""
import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Any

from . import pipeline, registry
from .runner import clean_log

log = logging.getLogger("omnibot.web")

START_TIME = time.time()
_bot_ref: Any = None


def set_bot(bot: Any) -> None:
    global _bot_ref
    _bot_ref = bot


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OmniBot | Universal Lua Deobfuscation Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;600&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0b0f19;
      --card-bg: #111827;
      --card-border: #1f2937;
      --primary: #6366f1;
      --primary-hover: #4f46e5;
      --primary-glow: rgba(99, 102, 241, 0.25);
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --text: #f3f4f6;
      --text-muted: #9ca3af;
      --code-bg: #030712;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg);
      color: var(--text);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      line-height: 1.5;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    header {
      background: rgba(17, 24, 39, 0.8);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--card-border);
      position: sticky;
      top: 0;
      z-index: 50;
    }
    .header-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 1rem 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      font-size: 1.35rem;
      font-weight: 800;
      color: #fff;
      text-decoration: none;
    }
    .logo-badge {
      background: linear-gradient(135deg, #6366f1, #a855f7);
      width: 36px;
      height: 36px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 0 15px var(--primary-glow);
    }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.35rem 0.85rem;
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 9999px;
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--success);
    }
    .pulse-dot {
      width: 8px;
      height: 8px;
      background: var(--success);
      border-radius: 50%;
      box-shadow: 0 0 8px var(--success);
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(0.85); }
    }
    main {
      flex: 1;
      max-width: 1200px;
      margin: 0 auto;
      padding: 2.5rem 1.5rem;
      width: 100%;
    }
    .hero {
      text-align: center;
      margin-bottom: 3rem;
    }
    .hero h1 {
      font-size: 2.75rem;
      font-weight: 800;
      letter-spacing: -0.025em;
      margin-bottom: 0.75rem;
      background: linear-gradient(to right, #fff, #9ca3af);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .hero p {
      color: var(--text-muted);
      font-size: 1.15rem;
      max-width: 650px;
      margin: 0 auto;
    }
    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1.25rem;
      margin-bottom: 2.5rem;
    }
    .metric-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 1.25rem 1.5rem;
      transition: transform 0.2s, border-color 0.2s;
    }
    .metric-card:hover {
      border-color: rgba(99, 102, 241, 0.4);
      transform: translateY(-2px);
    }
    .metric-label {
      color: var(--text-muted);
      font-size: 0.85rem;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.35rem;
    }
    .metric-value {
      font-size: 1.75rem;
      font-weight: 700;
      color: #fff;
    }
    .section-title {
      font-size: 1.4rem;
      font-weight: 700;
      margin-bottom: 1.25rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .engines-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.25rem;
      margin-bottom: 3rem;
    }
    .engine-card {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 1.25rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .engine-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 0.75rem;
    }
    .engine-name {
      font-weight: 700;
      font-size: 1.1rem;
      color: #fff;
    }
    .badge {
      display: inline-block;
      padding: 0.2rem 0.55rem;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: 600;
    }
    .badge-ready { background: rgba(16, 185, 129, 0.15); color: #34d399; }
    .badge-offline { background: rgba(245, 158, 11, 0.15); color: #fbbf24; }
    .badge-sandbox { background: rgba(99, 102, 241, 0.15); color: #818cf8; margin-top: 0.5rem; display: inline-block; }
    .engine-desc {
      color: var(--text-muted);
      font-size: 0.9rem;
      margin-bottom: 1rem;
    }
    .web-tool-box {
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 2rem;
      margin-bottom: 3rem;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
    }
    .form-group {
      margin-bottom: 1.25rem;
    }
    label {
      display: block;
      font-size: 0.9rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: #e5e7eb;
    }
    textarea, select {
      width: 100%;
      background: var(--code-bg);
      border: 1px solid var(--card-border);
      border-radius: 10px;
      padding: 0.85rem 1rem;
      color: #f3f4f6;
      font-family: 'Fira Code', monospace;
      font-size: 0.9rem;
      resize: vertical;
      transition: border-color 0.2s;
    }
    textarea:focus, select:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px var(--primary-glow);
    }
    .btn {
      background: var(--primary);
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 0.85rem 1.75rem;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      transition: background 0.2s, transform 0.1s;
    }
    .btn:hover {
      background: var(--primary-hover);
      transform: translateY(-1px);
    }
    .btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }
    .output-box {
      display: none;
      margin-top: 1.5rem;
      border-top: 1px solid var(--card-border);
      padding-top: 1.5rem;
    }
    .output-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.75rem;
    }
    .copy-btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid var(--card-border);
      color: var(--text);
      padding: 0.4rem 0.85rem;
      border-radius: 6px;
      font-size: 0.85rem;
      cursor: pointer;
    }
    .copy-btn:hover { background: rgba(255, 255, 255, 0.15); }
    footer {
      border-top: 1px solid var(--card-border);
      padding: 1.5rem;
      text-align: center;
      color: var(--text-muted);
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <header>
    <div class="header-content">
      <a href="/" class="logo">
        <div class="logo-badge">⚡</div>
        <span>OmniBot</span>
      </a>
      <div class="status-pill">
        <div class="pulse-dot"></div>
        <span id="bot-status-text">Online & Ready</span>
      </div>
    </div>
  </header>

  <main>
    <div class="hero">
      <h1>Universal Lua & Luau Deobfuscation</h1>
      <p>All-in-one Discord bot & high-performance deobfuscation engine supporting 10 major obfuscators.</p>
    </div>

    <div class="metrics-grid">
      <div class="metric-card">
        <div class="metric-label">Uptime</div>
        <div class="metric-value" id="val-uptime">--</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Active Engines</div>
        <div class="metric-value" id="val-engines">-- / 10</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Discord Latency</div>
        <div class="metric-value" id="val-latency">--</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Connected Servers</div>
        <div class="metric-value" id="val-guilds">--</div>
      </div>
    </div>

    <div class="section-title">
      <span>🚀</span> Web Deobfuscator Sandbox
    </div>
    <div class="web-tool-box">
      <form id="deobf-form">
        <div class="form-group">
          <label for="engine-select">Target Deobfuscator</label>
          <select id="engine-select">
            <option value="auto">Auto-Detect Obfuscator (Recommended)</option>
            <option value="hercules">Hercules (Static Decompiler)</option>
            <option value="clyde">Clyde V2-V6 (Stack/Register VM)</option>
            <option value="prometheus">Prometheus / WeAreDevs</option>
            <option value="ironveil">Ironveil V1</option>
            <option value="luraph">Luraph v15</option>
            <option value="moonveil">Moonveil</option>
            <option value="77fuscator">77fuscator</option>
            <option value="moonsec">MoonSec V3</option>
            <option value="ironbrew2">IronBrew 2</option>
            <option value="centurion">Centurion</option>
          </select>
        </div>
        <div class="form-group">
          <label for="script-input">Paste Obfuscated Script</label>
          <textarea id="script-input" rows="8" placeholder="-- Paste Lua / Luau obfuscated code here..."></textarea>
        </div>
        <button type="submit" class="btn" id="run-btn">
          <span>⚡ Deobfuscate Code</span>
        </button>
      </form>

      <div class="output-box" id="output-box">
        <div class="output-header">
          <span style="font-weight: 600; color: #fff;" id="output-title">Deobfuscation Result</span>
          <button type="button" class="copy-btn" id="copy-btn">📋 Copy Result</button>
        </div>
        <textarea id="output-text" rows="12" readonly></textarea>
      </div>
    </div>

    <div class="section-title">
      <span>⚙️</span> Deobfuscator Engines Status
    </div>
    <div class="engines-grid" id="engines-container">
      <!-- Loaded dynamically via JavaScript -->
    </div>
  </main>

  <footer>
    <p>OmniBot &copy; 2026. Keep-Alive endpoint active on <code>/health</code> for 24/7 hosting.</p>
  </footer>

  <script>
    async function updateStatus() {
      try {
        const res = await fetch('/api/status');
        if (!res.ok) return;
        const data = await res.json();
        
        document.getElementById('val-uptime').innerText = data.uptime;
        document.getElementById('val-engines').innerText = data.ready_engines + ' / ' + data.total_engines;
        document.getElementById('val-latency').innerText = data.latency_ms !== null ? data.latency_ms + 'ms' : 'Ready';
        document.getElementById('val-guilds').innerText = data.guilds;

        const container = document.getElementById('engines-container');
        container.innerHTML = '';
        data.engines.forEach(eng => {
          const card = document.createElement('div');
          card.className = 'engine-card';
          const isReady = eng.status === 'ready';
          card.innerHTML = `
            <div>
              <div class="engine-header">
                <span class="engine-name">${eng.name}</span>
                <span class="badge ${isReady ? 'badge-ready' : 'badge-offline'}">${isReady ? 'Ready' : 'Unavailable'}</span>
              </div>
              <p class="engine-desc">${eng.desc}</p>
              ${eng.sandboxed ? '<span class="badge badge-sandbox">Sandboxed Luau</span>' : ''}
            </div>
            ${eng.reason ? '<div style="font-size:0.8rem; color:#f59e0b; margin-top:0.75rem;">↳ ' + eng.reason + '</div>' : ''}
          `;
          container.appendChild(card);
        });
      } catch (err) {
        console.error('Status fetch error:', err);
      }
    }

    document.getElementById('deobf-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const code = document.getElementById('script-input').value.trim();
      const tool = document.getElementById('engine-select').value;
      if (!code) return alert('Please paste some code first!');

      const btn = document.getElementById('run-btn');
      const outBox = document.getElementById('output-box');
      const outText = document.getElementById('output-text');
      const outTitle = document.getElementById('output-title');

      btn.disabled = true;
      btn.innerHTML = '<span>⏳ Processing...</span>';
      outBox.style.display = 'none';

      try {
        const res = await fetch('/api/deobfuscate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ script: code, tool: tool })
        });
        const result = await res.json();
        outBox.style.display = 'block';

        if (result.ok) {
          outTitle.innerText = '✅ Deobfuscated by ' + result.tool;
          outText.value = result.code || result.notes.join('\n');
        } else {
          outTitle.innerText = '❌ Deobfuscation Failed';
          outText.value = (result.notes || []).join('\n') || 'Could not deobfuscate input.';
        }
      } catch (err) {
        outBox.style.display = 'block';
        outTitle.innerText = '❌ Error';
        outText.value = 'Network error: ' + err.message;
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>⚡ Deobfuscate Code</span>';
      }
    });

    document.getElementById('copy-btn').addEventListener('click', () => {
      const outText = document.getElementById('output-text');
      outText.select();
      navigator.clipboard.writeText(outText.value);
      alert('Copied to clipboard!');
    });

    updateStatus();
    setInterval(updateStatus, 15000);
  </script>
</body>
</html>
"""


def _format_uptime(seconds: float) -> str:
    secs = int(seconds)
    hours, rem = divmod(secs, 3600)
    mins, s = divmod(rem, 60)
    if hours > 0:
        return f"{hours}h {mins}m"
    return f"{mins}m {s}s"


async def start_web_server(bot: Any = None, host: str = "0.0.0.0", port: int = 7860) -> Any:
    """Launches the aiohttp web dashboard and health check server asynchronously."""
    try:
        from aiohttp import web
    except ImportError:
        log.warning("aiohttp is not installed; web dashboard disabled.")
        return None

    if bot is not None:
        set_bot(bot)

    app = web.Application()

    async def handle_index(request: web.Request) -> web.Response:
        return web.Response(text=DASHBOARD_HTML, content_type="text/html")

    async def handle_health(request: web.Request) -> web.Response:
        """Lightweight 24/7 keep-alive endpoint for UptimeRobot / cron-job.org."""
        is_ready = bool(_bot_ref and getattr(_bot_ref, "is_ready", lambda: False)())
        return web.json_response({
            "status": "ok",
            "bot_connected": is_ready,
            "uptime_seconds": int(time.time() - START_TIME)
        })

    async def handle_api_status(request: web.Request) -> web.Response:
        """Detailed status JSON for the dashboard metrics and cards."""
        uptime_sec = time.time() - START_TIME
        ready_count = 0
        engines_data = []

        for t in registry.TOOL_LIST:
            why = registry.available(t)
            is_ready = not bool(why)
            if is_ready:
                ready_count += 1
            engines_data.append({
                "key": t.key,
                "name": t.name,
                "desc": t.desc,
                "sandboxed": t.sandboxed,
                "status": "ready" if is_ready else "unavailable",
                "reason": why
            })

        latency = None
        guild_count = 0
        if _bot_ref and hasattr(_bot_ref, "latency"):
            try:
                latency = round(_bot_ref.latency * 1000)
                guild_count = len(getattr(_bot_ref, "guilds", []))
            except Exception:
                pass

        return web.json_response({
            "uptime": _format_uptime(uptime_sec),
            "ready_engines": ready_count,
            "total_engines": len(registry.TOOL_LIST),
            "latency_ms": latency,
            "guilds": guild_count,
            "engines": engines_data
        })

    async def handle_api_deobf(request: web.Request) -> web.Response:
        """Web interface for deobfuscating code."""
        try:
            body = await request.json()
            script_text = body.get("script", "")
            tool_key = body.get("tool", "auto")

            if not script_text.strip():
                return web.json_response({"ok": False, "notes": ["Input code is empty."]}, status=400)

            data = script_text.encode("utf-8")
            allow_sandboxed = os.environ.get("ALLOW_SANDBOXED", "1") == "1"
            res = await pipeline.deobfuscate(data, tool_key if tool_key != "auto" else None, allow_sandboxed=allow_sandboxed)

            code_out = ""
            for name, path in res.files:
                if path.exists() and path.stat().st_size > 0:
                    try:
                        code_out = path.read_text("utf-8", errors="replace")
                        break
                    except Exception:
                        pass

            notes_clean = [clean_log(n).strip() for n in res.notes if clean_log(n).strip()]
            res.cleanup()

            return web.json_response({
                "ok": res.ok,
                "tool": res.tool.name if res.tool else None,
                "code": code_out,
                "notes": notes_clean
            })
        except Exception as e:
            log.exception("Web deobf handler error")
            return web.json_response({"ok": False, "notes": [f"Server error: {e}"]}, status=500)

    app.router.add_get("/", handle_index)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/api/status", handle_api_status)
    app.router.add_post("/api/deobfuscate", handle_api_deobf)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)

    try:
        await site.start()
        log.info("Dashboard & Keep-Alive server listening at http://%s:%d", host, port)
        return runner
    except Exception as e:
        log.warning("Could not bind dashboard to http://%s:%d: %s", host, port, e)
        return None
