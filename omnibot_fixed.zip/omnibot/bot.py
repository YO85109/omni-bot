"""OmniBot - one Discord bot, many Lua/Luau deobfuscators."""
import asyncio
import io
import logging
import os
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import discord
from discord import app_commands
from discord.ext import commands

from omni import moonveil, pipeline, registry
from omni.fetch import FetchError, extract_filename, fetch_url
from omni.runner import clean_log as clean

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger("omnibot")

ROOT = Path(__file__).resolve().parent
START_TIME = time.time()


def load_env(path: Path = ROOT / ".env") -> None:
    if path.exists():
        for line in path.read_text("utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export "):].strip()
            if "=" in line:
                k, _, v = line.partition("=")
                key = k.strip()
                val = v.strip().strip("\"'")
                os.environ.setdefault(key, val)


load_env()
TOKEN = os.environ.get("DISCORD_TOKEN", "")
PREFIX = os.environ.get("PREFIX", ".")
OWNERS = {int(x) for x in re.split(r"[,\s]+", os.environ.get("OWNER_IDS", "").strip()) if x.isdigit()}
ALLOWED_GUILDS = {int(x) for x in re.split(r"[,\s]+", os.environ.get("ALLOWED_GUILDS", "").strip()) if x.isdigit()}
MAX_INPUT = int(os.environ.get("MAX_INPUT_MB", "8")) << 20
MAX_CONCURRENT = max(1, int(os.environ.get("MAX_CONCURRENT", "2")))
MAX_QUEUE = max(1, int(os.environ.get("MAX_QUEUE", "20")))
COOLDOWN = float(os.environ.get("USER_COOLDOWN_S", "20"))
ALLOW_SANDBOXED = os.environ.get("ALLOW_SANDBOXED", "1") == "1"
DISCORD_LIMIT = 24 * 1024 * 1024  # Max total file payload in one message
MAX_FILES = 10                     # Discord hard limit per message

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(
    command_prefix=commands.when_mentioned_or(PREFIX),
    intents=intents,
    help_command=None
)

_sem = asyncio.Semaphore(MAX_CONCURRENT)
_mv_lock = asyncio.Lock()
_waiting = 0
_last_use = {}
_synced = False


def is_owner(uid: int) -> bool:
    return uid in OWNERS


def guild_ok(guild: Optional[discord.Guild], user_id: Optional[int] = None) -> bool:
    """Check guild permissions. If restricted to specific guilds, allow DMs only for owners."""
    if not ALLOWED_GUILDS:
        return True
    if guild is not None:
        return guild.id in ALLOWED_GUILDS
    # Direct Message
    return user_id is not None and is_owner(user_id)


def cooldown_left(uid: int) -> float:
    if is_owner(uid):
        return 0.0
    left = COOLDOWN - (time.monotonic() - _last_use.get(uid, -1e9))
    return max(0.0, left)


def format_duration(seconds: float) -> str:
    if seconds < 1.0:
        return f"{int(seconds * 1000)}ms"
    return f"{seconds:.2f}s"


class Busy(Exception):
    pass


class slot:
    """Concurrency slot with a bounded waiting queue."""

    async def __aenter__(self):
        global _waiting
        if _waiting >= MAX_QUEUE:
            raise Busy("The deobfuscation queue is currently full. Please try again shortly.")
        _waiting += 1
        try:
            await _sem.acquire()
        finally:
            _waiting -= 1

    async def __aexit__(self, *a):
        _sem.release()


# --------------------------------------------------------------------------- interactive UI views
class DeobfResultView(discord.ui.View):
    """Interactive controls for deobfuscation results: quick code preview and dismissal."""

    def __init__(self, author_id: int, preview_data: Optional[Tuple[str, str]] = None, timeout: float = 300.0):
        super().__init__(timeout=timeout)
        self.author_id = author_id
        self.preview_data = preview_data
        if not preview_data:
            for child in self.children:
                if getattr(child, "custom_id", None) == "preview_btn":
                    child.disabled = True

    @discord.ui.button(label="Quick Preview", style=discord.ButtonStyle.secondary, emoji="👁️", custom_id="preview_btn")
    async def preview_btn(self, i: discord.Interaction, button: discord.ui.Button):
        if not self.preview_data:
            return await i.response.send_message("No code preview available.", ephemeral=True)
        name, code = self.preview_data
        emb = discord.Embed(
            title=f"Code Preview: {name}",
            description=f"```lua\n{code}\n```",
            colour=discord.Colour.dark_teal()
        )
        await i.response.send_message(embed=emb, ephemeral=True)

    @discord.ui.button(label="Dismiss", style=discord.ButtonStyle.danger, emoji="🗑️", custom_id="dismiss_btn")
    async def dismiss_btn(self, i: discord.Interaction, button: discord.ui.Button):
        is_mod = i.user.guild_permissions.manage_messages if i.guild else False
        if i.user.id == self.author_id or is_mod or is_owner(i.user.id):
            await i.message.delete()
        else:
            await i.response.send_message("Only the requester or moderators can dismiss this message.", ephemeral=True)


class ToolDetailSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label=t.name,
                value=t.key,
                description=t.desc[:100],
                emoji="✅" if not registry.available(t) else "⚠️"
            ) for t in registry.TOOL_LIST[:25]
        ]
        super().__init__(placeholder="Select an engine to inspect details...", min_values=1, max_values=1, options=options)

    async def callback(self, i: discord.Interaction):
        tool_key = self.values[0]
        t = registry.TOOLS_BY_KEY.get(tool_key)
        if not t:
            return await i.response.send_message("Tool not found.", ephemeral=True)
        why = registry.available(t)
        emb = discord.Embed(
            title=f"{t.name} (`{t.key}`)",
            colour=discord.Colour.green() if not why else discord.Colour.orange(),
            description=t.desc
        )
        emb.add_field(name="Engine Status", value="✅ Ready" if not why else f"⚠️ Unavailable: {why}", inline=True)
        emb.add_field(name="Mode", value="Sandboxed Luau" if t.sandboxed else "Static Analysis", inline=True)
        emb.add_field(name="Timeout", value=f"{t.timeout}s", inline=True)
        sigs = ", ".join(f"`{s}`" for s in t.sigs)
        emb.add_field(name="Detection Signatures", value=sigs[:1000] or "None", inline=False)
        await i.response.send_message(embed=emb, ephemeral=True)


class ToolsView(discord.ui.View):
    def __init__(self, timeout: float = 180.0):
        super().__init__(timeout=timeout)
        self.add_item(ToolDetailSelect())


class MoonveilView(discord.ui.View):
    def __init__(self, user_id: int, timeout: float = 300.0):
        super().__init__(timeout=timeout)
        self.user_id = user_id

    @discord.ui.button(label="Reset Session", style=discord.ButtonStyle.secondary, emoji="🔄")
    async def reset_btn(self, i: discord.Interaction, button: discord.ui.Button):
        if i.user.id != self.user_id and not is_owner(i.user.id):
            return await i.response.send_message("This is not your session.", ephemeral=True)
        had = moonveil.clear(self.user_id)
        msg = "✅ Moonveil session cleared." if had else "ℹ️ No pending session found."
        await i.response.send_message(msg, ephemeral=True)


# --------------------------------------------------------------------------- input resolution
async def read_attachment(att: discord.Attachment) -> Tuple[str, bytes]:
    if att.size > MAX_INPUT:
        raise FetchError("attachment is larger than %d MB" % (MAX_INPUT >> 20))
    data = await att.read()
    if not data or not data.strip():
        raise FetchError("attachment is empty (0 bytes)")
    return att.filename or "script.lua", data


async def resolve_message_input(ctx: commands.Context, arg: Optional[str]) -> Tuple[str, bytes]:
    """Resolves input from attachment on message -> replied-to message attachment -> URL argument."""
    msg = ctx.message

    # 1. Direct attachment on current message
    if msg.attachments:
        return await read_attachment(msg.attachments[0])

    # 2. Attachment in replied message
    if msg.reference and msg.reference.message_id:
        try:
            ref = msg.reference.resolved
            if not isinstance(ref, discord.Message):
                ref = await ctx.channel.fetch_message(msg.reference.message_id)
            if ref and ref.attachments:
                return await read_attachment(ref.attachments[0])
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass

    # 3. URL argument
    if arg and re.match(r"https?://", arg.strip(), re.I):
        url = arg.strip()
        filename = extract_filename(url)
        return filename, await fetch_url(url)

    raise FetchError("Attach a script file, reply to a message containing one, or provide a URL.")


def tool_choices() -> List[app_commands.Choice[str]]:
    return [app_commands.Choice(name="Auto-Detect", value="auto")] + [
        app_commands.Choice(name=t.name, value=t.key) for t in registry.TOOL_LIST
    ]


# --------------------------------------------------------------------------- core runner
async def do_deobf(data: bytes, tool: str) -> pipeline.Outcome:
    async with slot():
        return await pipeline.deobfuscate(data, tool, allow_sandboxed=ALLOW_SANDBOXED)


def build_reply(
    filename: str,
    out: pipeline.Outcome,
    elapsed: Optional[float] = None
) -> Tuple[discord.Embed, List[discord.File], Optional[Tuple[str, str]]]:
    clean_notes = [clean(n).strip() for n in out.notes if clean(n).strip()]

    if out.ok:
        tool_name = out.tool.name if out.tool else "Tool"
        desc = f"**{tool_name}** successfully deobfuscated `{filename[:80]}`"
        emb = discord.Embed(title="Deobfuscation Successful", colour=discord.Colour.green(), description=desc)
    else:
        desc_text = "\n\n".join(clean_notes)[:1800] if clean_notes else "No deobfuscator was able to process this file."
        emb = discord.Embed(title="Deobfuscation Failed", colour=discord.Colour.red(), description=desc_text)

    if elapsed is not None:
        emb.add_field(name="Elapsed Time", value=format_duration(elapsed), inline=True)

    files, total_size = [], 0
    skipped_large = []
    skipped_count = []
    preview_data = None

    for name, path in out.files:
        if not path.exists():
            continue
        size = path.stat().st_size
        if size == 0:
            continue

        # Extract preview snippet for the first valid output
        if out.ok and preview_data is None:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    lines = [f.readline() for _ in range(35)]
                snip = "".join(lines).strip()
                if snip:
                    preview_data = (name, snip[:3500])
            except Exception:
                pass

        if len(files) >= MAX_FILES:
            skipped_count.append(name)
            continue

        if total_size + size > DISCORD_LIMIT:
            skipped_large.append(name)
            continue

        total_size += size
        try:
            files.append(discord.File(io.BytesIO(path.read_bytes()), filename=name))
        except Exception:
            pass

    if skipped_large:
        emb.add_field(name="Skipped (File Size)", value=", ".join(f"`{f}`" for f in skipped_large)[:500], inline=False)
    if skipped_count:
        emb.add_field(name="Skipped (10 Attachment Limit)", value=", ".join(f"`{f}`" for f in skipped_count)[:500], inline=False)

    if out.ok and clean_notes:
        last_note = clean_notes[-1][:900]
        if last_note:
            emb.add_field(name="Output Summary", value=f"```\n{last_note}\n```", inline=False)

    return emb, files, preview_data


# --------------------------------------------------------------------------- slash commands
@bot.tree.command(name="deobf", description="Deobfuscate a Lua/Luau script (auto-detects the obfuscator)")
@app_commands.describe(
    file="The obfuscated script file",
    url="Or a direct URL to the script (pastebin, raw GitHub, etc.)",
    tool="Force a specific deobfuscator"
)
@app_commands.choices(tool=tool_choices())
async def deobf_slash(
    i: discord.Interaction,
    file: Optional[discord.Attachment] = None,
    url: Optional[str] = None,
    tool: Optional[app_commands.Choice[str]] = None
):
    if not guild_ok(i.guild, i.user.id):
        return await i.response.send_message("This bot is not enabled in this server/DM.", ephemeral=True)

    left = cooldown_left(i.user.id)
    if left > 0:
        return await i.response.send_message(f"Cooldown active: please wait {int(left + 1)}s.", ephemeral=True)

    if not file and not url:
        return await i.response.send_message("Please provide either a `file` attachment or a `url`.", ephemeral=True)

    await i.response.defer(thinking=True)
    t0 = time.monotonic()
    out = None

    try:
        if file:
            name, data = await read_attachment(file)
        else:
            name = extract_filename(url)
            data = await fetch_url(url)

        _last_use[i.user.id] = time.monotonic()
        tool_val = tool.value if tool else "auto"
        out = await do_deobf(data, tool_val)
        elapsed = time.monotonic() - t0

        emb, files, preview_data = build_reply(name, out, elapsed=elapsed)
        view = DeobfResultView(i.user.id, preview_data)
        await i.followup.send(embed=emb, files=files, view=view)
    except (FetchError, Busy) as e:
        await i.followup.send(f"⚠️ {e}")
    except Exception as e:
        log.exception("Slash deobf encountered an unexpected error")
        await i.followup.send(f"❌ Internal error: `{e}`. Check bot console logs.")
    finally:
        if out:
            out.cleanup()


@bot.tree.command(name="tools", description="List supported obfuscators and their status on this host")
async def tools_slash(i: discord.Interaction):
    lines = []
    for t in registry.TOOL_LIST:
        why = registry.available(t)
        status_icon = "✅" if not why else "⚠️"
        sandbox_badge = " *(Sandboxed Luau)*" if t.sandboxed else ""
        reason = f"\n    ↳ _{why}_" if why else ""
        lines.append(f"{status_icon} **{t.name}**{sandbox_badge} - {t.desc}{reason}")

    emb = discord.Embed(
        title="Supported Obfuscators & Engine Status",
        description="\n".join(lines)[:4000],
        colour=discord.Colour.blue()
    )
    await i.response.send_message(embed=emb, view=ToolsView(), ephemeral=True)


@bot.tree.command(name="moonveil", description="Moonveil Step 1: Generate a Roblox executor trace harness")
@app_commands.describe(
    file="The Moonveil script file",
    url="Or a direct URL to the Moonveil script"
)
async def moonveil_slash(
    i: discord.Interaction,
    file: Optional[discord.Attachment] = None,
    url: Optional[str] = None
):
    await _moonveil_phase1(i, file, url)


@bot.tree.command(name="trace", description="Moonveil Step 2: Upload moonveil_trace.txt to rebuild source")
@app_commands.describe(
    file="The generated moonveil_trace.txt",
    file2="Optional second trace to merge additional execution coverage",
    file3="Optional third trace to merge additional execution coverage"
)
async def trace_slash(
    i: discord.Interaction,
    file: discord.Attachment,
    file2: Optional[discord.Attachment] = None,
    file3: Optional[discord.Attachment] = None
):
    if not guild_ok(i.guild, i.user.id):
        return await i.response.send_message("This bot is not enabled in this server/DM.", ephemeral=True)

    await i.response.defer(thinking=True)
    atts = [a for a in (file, file2, file3) if a]
    try:
        datas = [(await read_attachment(a))[1] for a in atts]
        async with slot():
            async with _mv_lock:
                ok, lines, stats, path = await moonveil.phase2(i.user.id, datas)

        desc = "\n".join(clean(l).strip() for l in lines if clean(l).strip())[:1500] or (
            "Trace devirtualization completed." if ok else "Reconstruction failed."
        )
        emb = discord.Embed(
            title="Moonveil Reconstruction" if ok else "Reconstruction Failed",
            colour=discord.Colour.green() if ok else discord.Colour.red(),
            description=desc
        )
        for k, v in stats.items():
            val = str(v).strip()
            if val:
                emb.add_field(name=k, value=val[:200], inline=True)

        files = []
        if ok and path and path.exists() and path.stat().st_size > 0:
            files.append(discord.File(io.BytesIO(path.read_bytes()), filename="moonveil_devirtualized.lua"))

        await i.followup.send(embed=emb, files=files)
    except (FetchError, Busy) as e:
        await i.followup.send(f"⚠️ {e}")
    except Exception as e:
        log.exception("Trace upload failed")
        await i.followup.send(f"❌ Internal error: `{e}`. Check bot console logs.")


@bot.tree.command(name="moonveil_reset", description="Discard your pending Moonveil session")
async def moonveil_reset(i: discord.Interaction):
    had = moonveil.clear(i.user.id)
    msg = "✅ Your pending Moonveil session was cleared." if had else "ℹ️ No pending Moonveil session found."
    await i.response.send_message(msg, ephemeral=True)


@bot.tree.command(name="ping", description="Check bot latency and responsiveness")
async def ping_slash(i: discord.Interaction):
    latency = round(bot.latency * 1000)
    await i.response.send_message(f"🏓 Pong! Latency: `{latency}ms`", ephemeral=True)


@bot.tree.command(name="status", description="Show bot health, uptime, and system status")
async def status_slash(i: discord.Interaction):
    uptime = int(time.time() - START_TIME)
    hours, remainder = divmod(uptime, 3600)
    minutes, seconds = divmod(remainder, 60)
    ready_tools = sum(1 for t in registry.TOOL_LIST if not registry.available(t))
    total_tools = len(registry.TOOL_LIST)

    emb = discord.Embed(title="OmniBot System Status", colour=discord.Colour.teal())
    emb.add_field(name="Uptime", value=f"{hours}h {minutes}m {seconds}s", inline=True)
    emb.add_field(name="Engine Tools", value=f"{ready_tools}/{total_tools} ready", inline=True)
    emb.add_field(name="Queue Waiting", value=str(_waiting), inline=True)
    emb.add_field(name="Sandboxing", value="Enabled" if ALLOW_SANDBOXED else "Disabled", inline=True)
    emb.add_field(name="Guilds", value=str(len(bot.guilds)), inline=True)
    emb.add_field(name="Gateway Latency", value=f"{round(bot.latency * 1000)}ms", inline=True)
    await i.response.send_message(embed=emb, ephemeral=True)


async def _moonveil_phase1(target, file, url):
    is_i = isinstance(target, discord.Interaction)
    send = target.followup.send if is_i else target.reply
    user_id = target.user.id if is_i else target.author.id
    guild = target.guild if is_i else target.guild

    if not guild_ok(guild, user_id):
        msg = "This bot is not enabled in this server/DM."
        if is_i:
            return await target.response.send_message(msg, ephemeral=True)
        return await target.reply(msg)

    if is_i:
        await target.response.defer(thinking=True)

    try:
        if file:
            name, data = await read_attachment(file)
        elif url:
            name = extract_filename(url)
            data = await fetch_url(url)
        else:
            return await send("⚠️ Attach a Moonveil script or pass a URL.")

        async with slot():
            async with _mv_lock:
                ok, lines, path = await moonveil.phase1(user_id, name, data)

        if not ok:
            err_text = "\n".join(clean(l).strip() for l in lines if clean(l).strip()) or "Failed to generate harness."
            return await send(f"❌ {err_text}")

        msg_text = (
            "**Step 1 Complete!**\n"
            "1. Run the attached `moonveil_roblox_trace.luau` in your executor inside Roblox.\n"
            "2. When done, submit the generated `moonveil_trace.txt` with `/trace` (or `.trace`).\n"
            "*(You can run multiple games/paths and submit up to 3 trace files at once to maximize coverage)*"
        )
        view = MoonveilView(user_id)
        await send(msg_text, file=discord.File(io.BytesIO(path.read_bytes()), filename=path.name), view=view)
    except (FetchError, Busy) as e:
        await send(f"⚠️ {e}")
    except Exception as e:
        log.exception("Moonveil phase 1 error")
        await send(f"❌ Internal error: `{e}`.")


# --------------------------------------------------------------------------- prefix commands
@bot.command(name="deobf", aliases=["d", "deobfuscate"])
async def deobf_prefix(ctx: commands.Context, tool: str = "auto", *, arg: Optional[str] = None):
    if not guild_ok(ctx.guild, ctx.author.id):
        return

    if tool != "auto" and tool not in registry.TOOLS_BY_KEY:
        arg = ((tool + " " + (arg or "")).strip())
        tool = "auto"

    left = cooldown_left(ctx.author.id)
    if left > 0:
        return await ctx.reply(f"Cooldown active: please wait {int(left + 1)}s.")

    async with ctx.typing():
        out = None
        t0 = time.monotonic()
        try:
            name, data = await resolve_message_input(ctx, arg)
            _last_use[ctx.author.id] = time.monotonic()
            out = await do_deobf(data, tool)
            elapsed = time.monotonic() - t0
            emb, files, preview_data = build_reply(name, out, elapsed=elapsed)
            view = DeobfResultView(ctx.author.id, preview_data)
            await ctx.reply(embed=emb, files=files, view=view)
        except (FetchError, Busy) as e:
            await ctx.reply(f"⚠️ {e}")
        except Exception as e:
            log.exception("Prefix deobf failed")
            await ctx.reply(f"❌ Internal error: `{e}`. Check console logs.")
        finally:
            if out:
                out.cleanup()


@bot.command(name="moonveil", aliases=["mv"])
async def moonveil_prefix(ctx: commands.Context, *, arg: Optional[str] = None):
    try:
        att = ctx.message.attachments[0] if ctx.message.attachments else None
        if not att and ctx.message.reference and ctx.message.reference.message_id:
            try:
                ref = ctx.message.reference.resolved
                if not isinstance(ref, discord.Message):
                    ref = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                if ref and ref.attachments:
                    att = ref.attachments[0]
            except Exception:
                pass
        await _moonveil_phase1(ctx.message, att, arg if arg and arg.startswith("http") else None)
    except Exception as e:
        log.exception("Prefix moonveil failed")
        await ctx.reply(f"❌ Internal error: `{e}`.")


@bot.command(name="trace")
async def trace_prefix(ctx: commands.Context):
    if not guild_ok(ctx.guild, ctx.author.id):
        return
    atts = ctx.message.attachments
    if not atts and ctx.message.reference and ctx.message.reference.message_id:
        try:
            ref = ctx.message.reference.resolved
            if not isinstance(ref, discord.Message):
                ref = await ctx.channel.fetch_message(ctx.message.reference.message_id)
            if ref and ref.attachments:
                atts = ref.attachments
        except Exception:
            pass

    if not atts:
        return await ctx.reply("⚠️ Attach your `moonveil_trace.txt` file or reply to a message containing it.")

    async with ctx.typing():
        try:
            datas = [(await read_attachment(a))[1] for a in atts[:3]]
            async with slot():
                async with _mv_lock:
                    ok, lines, stats, path = await moonveil.phase2(ctx.author.id, datas)

            desc = "\n".join(clean(l).strip() for l in lines if clean(l).strip())[:1500] or (
                "Trace devirtualization completed." if ok else "Reconstruction failed."
            )
            emb = discord.Embed(
                title="Moonveil Reconstruction" if ok else "Reconstruction Failed",
                colour=discord.Colour.green() if ok else discord.Colour.red(),
                description=desc
            )
            for k, v in stats.items():
                val = str(v).strip()
                if val:
                    emb.add_field(name=k, value=val[:200], inline=True)

            files = []
            if ok and path and path.exists() and path.stat().st_size > 0:
                files.append(discord.File(io.BytesIO(path.read_bytes()), filename="moonveil_devirtualized.lua"))

            await ctx.reply(embed=emb, files=files)
        except (FetchError, Busy) as e:
            await ctx.reply(f"⚠️ {e}")
        except Exception as e:
            log.exception("Prefix trace failed")
            await ctx.reply(f"❌ Internal error: `{e}`.")


@bot.command(name="tools", aliases=["help", "h"])
async def tools_prefix(ctx: commands.Context):
    lines = [f"`{PREFIX}deobf [tool] <attachment | reply | url>` or `/deobf`\n"]
    for t in registry.TOOL_LIST:
        why = registry.available(t)
        icon = "✅" if not why else "⚠️"
        sb = " *(sandboxed)*" if t.sandboxed else ""
        lines.append(f"{icon} `{t.key}` - {t.name}{sb}" + (f" (_{why}_)" if why else ""))
    await ctx.reply("\n".join(lines)[:1900], view=ToolsView())


@bot.command(name="ping")
async def ping_prefix(ctx: commands.Context):
    latency = round(bot.latency * 1000)
    await ctx.reply(f"🏓 Pong! Latency: `{latency}ms`")


@bot.command(name="status")
async def status_prefix(ctx: commands.Context):
    uptime = int(time.time() - START_TIME)
    hours, remainder = divmod(uptime, 3600)
    minutes, seconds = divmod(remainder, 60)
    ready_tools = sum(1 for t in registry.TOOL_LIST if not registry.available(t))
    total_tools = len(registry.TOOL_LIST)

    emb = discord.Embed(title="OmniBot System Status", colour=discord.Colour.teal())
    emb.add_field(name="Uptime", value=f"{hours}h {minutes}m {seconds}s", inline=True)
    emb.add_field(name="Tools", value=f"{ready_tools}/{total_tools} ready", inline=True)
    emb.add_field(name="Queue Waiting", value=str(_waiting), inline=True)
    emb.add_field(name="Sandboxing", value="Enabled" if ALLOW_SANDBOXED else "Disabled", inline=True)
    emb.add_field(name="Latency", value=f"{round(bot.latency * 1000)}ms", inline=True)
    await ctx.reply(embed=emb)


@bot.command(name="sync")
async def sync_prefix(ctx: commands.Context):
    """Owner command: immediately sync slash commands."""
    if not is_owner(ctx.author.id):
        return await ctx.reply("❌ Only bot owners can use this command.")

    async with ctx.typing():
        synced_count = 0
        try:
            if ALLOWED_GUILDS:
                for gid in ALLOWED_GUILDS:
                    g = discord.Object(gid)
                    bot.tree.copy_global_to(guild=g)
                    s = await bot.tree.sync(guild=g)
                    synced_count += len(s)
            else:
                s = await bot.tree.sync()
                synced_count = len(s)
            await ctx.reply(f"✅ Successfully synced {synced_count} slash commands.")
        except Exception as e:
            log.exception("Manual sync failed")
            await ctx.reply(f"❌ Slash sync failed: `{e}`.")


# --------------------------------------------------------------------------- error handling
@bot.event
async def on_command_error(ctx: commands.Context, error: Exception):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CommandOnCooldown):
        return await ctx.reply(f"⏳ Cooldown active: try again in {int(error.retry_after + 1)}s.")
    if isinstance(error, commands.CheckFailure):
        return
    log.warning("Command %s raised error: %s", getattr(ctx.command, "name", "unknown"), error)


@bot.tree.error
async def on_app_command_error(i: discord.Interaction, error: app_commands.AppCommandError):
    log.warning("Slash command error: %s", error)
    msg = f"⚠️ An error occurred: {error}"
    if i.response.is_done():
        try:
            await i.followup.send(msg, ephemeral=True)
        except Exception:
            pass
    else:
        try:
            await i.response.send_message(msg, ephemeral=True)
        except Exception:
            pass


# --------------------------------------------------------------------------- lifecycle
@bot.event
async def on_ready():
    global _synced
    log.info("Logged in as %s (ID: %s)", bot.user, bot.user.id if bot.user else "N/A")

    # Set presence
    activity = discord.Activity(type=discord.ActivityType.watching, name=f"{PREFIX}deobf | /deobf")
    await bot.change_presence(activity=activity)

    if not _synced:
        try:
            if ALLOWED_GUILDS:
                for gid in ALLOWED_GUILDS:
                    try:
                        g = discord.Object(gid)
                        bot.tree.copy_global_to(guild=g)
                        await bot.tree.sync(guild=g)
                        log.info("Synced slash commands to guild %s", gid)
                    except Exception as ge:
                        log.warning("Could not sync commands to guild %s: %s", gid, ge)
            else:
                await bot.tree.sync()
                log.info("Synced slash commands globally.")
            _synced = True
        except Exception:
            log.exception("Automatic slash command sync failed")

    for t in registry.TOOL_LIST:
        log.info("Tool %-11s : %s", t.key, registry.available(t) or "ready")

    # Start web dashboard & keep-alive server (for Hugging Face, Render, or Web use)
    if os.environ.get("ENABLE_WEB", "1") != "0":
        try:
            from omni import web as web_server
            web_port = int(os.environ.get("PORT", "7860"))
            asyncio.create_task(web_server.start_web_server(bot, port=web_port))
        except Exception as we:
            log.warning("Could not initialize web server: %s", we)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Set DISCORD_TOKEN in .env or the environment.")
    bot.run(TOKEN, log_handler=None)
