"""Moonveil is environment-locked, so it needs a two-phase flow:
   1) generate a trace harness for that exact build, the user runs it in their own Roblox executor
   2) user uploads the trace; we rebuild the executed paths into Lua.
"""
import json
import os
import re
import shutil
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import runner
from .registry import TOOLS, PY

MV = TOOLS / "moonveil"
DATA = Path(os.environ.get("DATA_DIR", Path(__file__).resolve().parent.parent / "data"))
SESS = DATA / "moonveil_sessions"
ACCUM_CAP = 64 * 1024 * 1024
_ANSI = re.compile(r"\x1b\[[0-9;]*m")


def _clean(s: str) -> str:
    return _ANSI.sub("", s or "")


def _sdir(uid: int) -> Path:
    d = SESS / str(uid)
    d.mkdir(parents=True, exist_ok=True)
    return d


def load(uid: int) -> Optional[dict]:
    d = SESS / str(uid)
    ip = d / "input.lua"
    if not ip.exists():
        return None
    meta = {}
    try:
        meta = json.loads((d / "meta.json").read_text("utf-8"))
    except Exception:
        pass
    n = 0
    try:
        n = int((d / "trace_count").read_text("utf-8").strip() or 0)
    except Exception:
        pass
    return {"input": ip, "filename": meta.get("filename", "input.lua"), "ts": meta.get("ts", 0), "traces": n}


def clear(uid: int) -> bool:
    d = SESS / str(uid)
    had = (d / "input.lua").exists()
    shutil.rmtree(d, ignore_errors=True)
    return had


async def phase1(uid: int, filename: str, data: bytes) -> Tuple[bool, List[str], Optional[Path]]:
    """Returns (ok, log_lines, harness_path)."""
    if not data or not data.strip():
        return False, ["uploaded script is empty"], None

    d = _sdir(uid)
    for f in ("trace_accum.txt", "trace_count"):
        (d / f).unlink(missing_ok=True)
    (d / "input.lua").write_bytes(data)
    (d / "meta.json").write_text(json.dumps({"filename": filename, "ts": time.time()}), "utf-8")
    out = d / "moonveil_roblox_trace.luau"
    out.unlink(missing_ok=True)
    r = await runner.run([PY, "gen_roblox_trace.py", str(d / "input.lua"), str(out)], MV, d, 120)
    log = [l for l in _clean(r.out).splitlines() if l.startswith(("[*]", "[!]"))]
    if out.exists() and out.stat().st_size > 0:
        return True, log, out
    err_msg = _clean(r.err).strip()[-300:] or _clean(r.out).strip()[-300:] or "harness not produced (not a recognised Moonveil build?)"
    log.append(err_msg)
    return False, log, None


def append_traces(uid: int, datas: List[bytes]) -> Tuple[Path, int]:
    d = _sdir(uid)
    accum = d / "trace_accum.txt"
    with open(accum, "ab") as h:
        for data in datas:
            h.write(data)
            if not data.endswith(b"\n"):
                h.write(b"\n")
    if accum.stat().st_size > ACCUM_CAP:
        with open(accum, "rb") as h:
            h.seek(-ACCUM_CAP, os.SEEK_END)
            tail = h.read()
        accum.write_bytes(tail)
    n = (load(uid) or {}).get("traces", 0) + len(datas)
    (d / "trace_count").write_text(str(n), "utf-8")
    return accum, n


async def phase2(uid: int, datas: List[bytes], no_antitamper: bool = False) -> Tuple[bool, List[str], Dict[str, str], Optional[Path]]:
    """Returns (ok, log_lines, stats, out_path)."""
    sess = load(uid)
    if not sess:
        return False, ["no pending session - run /moonveil with the script first"], {}, None

    valid_datas = [d for d in datas if d and d.strip()]
    if not valid_datas:
        return False, ["no valid trace data provided (file was empty)"], {}, None

    accum, n = append_traces(uid, valid_datas)
    d = _sdir(uid)
    produced = d / "moonveil_trace_devirt.lua"
    produced.unlink(missing_ok=True)
    env = {"MOONVEIL_OUT_DIR": str(d)}
    if no_antitamper:
        env["MOONVEIL_NO_ANTITAMPER"] = "1"
    r = await runner.run([PY, "reconstruct_from_trace.py", str(sess["input"]), str(accum)], MV, d, 320, env=env)
    out = _clean(r.out)
    log = [l for l in out.splitlines() if l.startswith(("[*]", "[!]"))]
    stats = {"traces merged": str(n)}
    m = re.search(r"parsed (\d+) trace blocks, (\d+) total entries", out)
    if m:
        stats["blocks"], stats["entries"] = m.group(1), m.group(2)
    covs = re.findall(r"proto_(\d+): \d+ instrs, \d+ traced pcs \((\d+)% coverage\)", out)
    if covs:
        stats["coverage"] = ", ".join("p%s %s%%" % c for c in covs[:6])
    if produced.exists() and produced.stat().st_size > 0:
        return True, log, stats, produced
    err_msg = _clean(r.err).strip()[-300:] or _clean(r.out).strip()[-300:] or "no devirtualized output produced"
    log.append(err_msg)
    return False, log, stats, None
