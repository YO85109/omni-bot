"""Fetch a script from a URL with SSRF protection and a size cap."""
import asyncio
import ipaddress
import re
import socket
from urllib.parse import urlparse, urljoin, unquote

MAX_BYTES = 8 * 1024 * 1024
MAX_REDIRECTS = 3


class FetchError(Exception):
    pass


def _public_host(host: str) -> None:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise FetchError("could not resolve host")
    for info in infos:
        raw_ip = info[4][0]
        ip = ipaddress.ip_address(raw_ip)
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                or ip.is_reserved or ip.is_unspecified):
            raise FetchError("refusing to fetch private/internal addresses")
        # Check IPv4-mapped IPv6 addresses as well
        mapped = getattr(ip, "ipv4_mapped", None)
        if mapped and (mapped.is_private or mapped.is_loopback or mapped.is_link_local):
            raise FetchError("refusing to fetch private/internal addresses")


def _to_raw(url: str) -> str:
    """Turn common paste-site / GitHub URLs into raw-content URLs."""
    p = urlparse(url)
    host = p.netloc.lower()
    path = p.path

    if host == "github.com" and "/blob/" in path:
        return "https://raw.githubusercontent.com" + path.replace("/blob/", "/", 1)
    if host in ("pastebin.com", "www.pastebin.com"):
        if not path.startswith("/raw/"):
            paste_id = path.strip("/")
            if paste_id:
                return f"https://pastebin.com/raw/{paste_id}"
    if host == "gist.github.com":
        if not path.endswith("/raw"):
            return url.rstrip("/") + "/raw"
    if host == "gitlab.com" and "/-/blob/" in path:
        return "https://gitlab.com" + path.replace("/-/blob/", "/-/raw/", 1)
    if host in ("rentry.co", "rentry.org") and not path.endswith("/raw"):
        clean_path = path.strip("/")
        if clean_path:
            return f"https://rentry.co/{clean_path}/raw"
    return url


def extract_filename(url: str, default: str = "script.lua") -> str:
    """Extract a clean, sanitized filename from a URL path, avoiding query parameters."""
    p = urlparse(url)
    path = unquote(p.path).rstrip("/")
    if "/" in path:
        base = path.rsplit("/", 1)[-1]
    else:
        base = path
    # Remove any query-string or fragment remnants and sanitize
    base = re.sub(r'[\\/*?:"<>|]', "", base).strip()
    if not base or base == "raw":
        base = default
    if not re.search(r"\.(lua|luau|txt)$", base, re.I):
        base += ".lua"
    return base[:60]


async def fetch_url(url: str) -> bytes:
    try:
        import aiohttp
    except ImportError:
        raise FetchError("aiohttp is not installed on this host")
    url = _to_raw(url.strip())
    timeout = aiohttp.ClientTimeout(total=30)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as s:
            for _ in range(MAX_REDIRECTS + 1):
                p = urlparse(url)
                if p.scheme not in ("http", "https") or not p.hostname:
                    raise FetchError("only http(s) URLs are supported")
                await asyncio.get_running_loop().run_in_executor(None, _public_host, p.hostname)
                async with s.get(url, allow_redirects=False, headers={"User-Agent": "omnibot/1.0"}) as r:
                    if r.status in (301, 302, 303, 307, 308) and r.headers.get("Location"):
                        url = urljoin(url, r.headers["Location"])
                        continue
                    if r.status != 200:
                        raise FetchError(f"server returned HTTP {r.status}")
                    buf = bytearray()
                    async for chunk in r.content.iter_chunked(65536):
                        buf += chunk
                        if len(buf) > MAX_BYTES:
                            raise FetchError("file is larger than %d MB" % (MAX_BYTES >> 20))
                    return bytes(buf)
            raise FetchError("too many redirects")
    except FetchError:
        raise
    except asyncio.TimeoutError:
        raise FetchError("connection timed out while downloading the script")
    except aiohttp.ClientError as e:
        raise FetchError(f"failed to download from URL: {e}")
    except OSError as e:
        raise FetchError(f"network error: {e}")
