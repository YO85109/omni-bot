"""Registry of every deobfuscator, how to detect its target, and how to invoke it."""
import os
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Awaitable, Callable, List, Optional, Tuple

from . import runner

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"

NODE = shutil.which("node") or "node"
DOTNET = shutil.which("dotnet") or "dotnet"
PY = sys.executable
JAVA = shutil.which("java")
UNLUAC = os.environ.get("UNLUAC_JAR", "")


@dataclass
class Job:
    src: Path               # input script on disk
    work: Path              # private per-job directory
    forced: bool = False    # user explicitly picked this tool (skip the tool's own "is this mine?" gate)
    timeout: int = 120


@dataclass
class Result:
    ok: bool
    files: List[Tuple[str, Path]] = field(default_factory=list)
    log: str = ""


@dataclass
class Tool:
    key: str
    name: str
    desc: str
    sandboxed: bool                      # executes (part of) the input inside a Luau sandbox
    sigs: List[str]                      # regexes (case-insensitive) used for auto-detection
    run: Callable[[Job], Awaitable[Result]]
    check: Callable[[], Optional[str]]   # returns a reason string if unavailable, else None
    timeout: int = 120


def _tail(*parts, n=1200):
    s = "\n".join(p.strip() for p in parts if p and p.strip())
    return s[-n:]


def _need(*bins):
    def check():
        for b in bins:
            if not shutil.which(b):
                return "`%s` is not installed on the host" % b
        return None
    return check


def _luau_missing():
    for name in ("luau", "luau-ast"):
        if not (shutil.which(name) or (TOOLS / "luraph" / "bin" / name).is_file()):
            return "Luau CLI (`%s`) not installed" % name
    return None


def _outfile(p: Path) -> bool:
    return p.exists() and p.stat().st_size > 0


# --------------------------------------------------------------------------- static JS tools
async def run_clyde(j: Job) -> Result:
    out = j.work / "clyde_deobfuscated.lua"
    cmd = [NODE, "cli.js", str(j.src), "-o", str(out)]
    if j.forced:
        cmd.append("--force")
    r = await runner.run(cmd, TOOLS / "clyde", j.work, j.timeout)
    files = [("clyde_deobfuscated.lua", out)] if _outfile(out) else []
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


async def run_prometheus(j: Job) -> Result:
    out = j.work / "prometheus_deobfuscated.lua"
    cmd = [NODE, "bin/pdeobf.js", str(j.src), "-o", str(out)]
    if j.forced:
        cmd.append("--force")
    r = await runner.run(cmd, TOOLS / "prometheus", j.work, j.timeout)
    files = [("prometheus_deobfuscated.lua", out)] if _outfile(out) else []
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


async def run_ironveil(j: Job) -> Result:
    out = j.work / "ironveil_deobfuscated.lua"
    r = await runner.run([NODE, "index.js", str(j.src), str(out)], TOOLS / "ironveil", j.work, j.timeout)
    files = [("ironveil_deobfuscated.lua", out)] if _outfile(out) else []
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


async def run_hercules(j: Job) -> Result:
    out = j.work / "hercules_deobfuscated.lua"
    r = await runner.run([PY, "deobfhercules.py", str(j.src), str(out)], TOOLS / "hercules", j.work, j.timeout)
    files = [("hercules_deobfuscated.lua", out)] if _outfile(out) else []
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


# --------------------------------------------------------------------------- .NET tools
async def _unluac(luac: Path, j: Job):
    """Optional: decompile recovered Lua 5.1 bytecode to source if unluac + java are present."""
    if not (JAVA and UNLUAC and os.path.isfile(UNLUAC)):
        return None
    out = j.work / (luac.stem + "_decompiled.lua")
    r = await runner.run([JAVA, "-Xmx512m", "-jar", UNLUAC, str(luac)], j.work, j.work, 90)
    if r.ok and r.out.strip():
        out.write_text(r.out, encoding="utf-8")
        return out
    return None


def _dll_missing(path: Path):
    def check():
        if not shutil.which("dotnet"):
            return "`dotnet` is not installed on the host"
        if not path.is_file():
            return "not built yet (run the dotnet build step, see README)"
        return None
    return check


MOONSEC_DLL = TOOLS / "moonsec" / "out" / "MoonsecDeobfuscator.dll"
F77_DLL = TOOLS / "77fuscator" / "out" / "deobfuscator.dll"
IB2_DLL = TOOLS / "ironbrew2" / "LuaAnalysis.Ironbrew2.dll"


async def run_moonsec(j: Job) -> Result:
    luac, dis = j.work / "moonsec.luac", j.work / "moonsec_disasm.txt"
    r1 = await runner.run([DOTNET, str(MOONSEC_DLL), "-dev", "-i", str(j.src), "-o", str(luac)],
                          MOONSEC_DLL.parent, j.work, j.timeout)
    r2 = await runner.run([DOTNET, str(MOONSEC_DLL), "-dis", "-i", str(j.src), "-o", str(dis)],
                          MOONSEC_DLL.parent, j.work, j.timeout)
    files = []
    if _outfile(luac):
        files.append(("moonsec.luac", luac))
        src = await _unluac(luac, j)
        if src:
            files.append((src.name, src))
    if _outfile(dis):
        files.append(("moonsec_disasm.txt", dis))
    note = "" if files and any(n.endswith(".lua") for n, _ in files) else \
        "\nOutput is Lua 5.1 bytecode; run it through unluac/luadec to get source."
    return Result(bool(files), files, _tail(r1.out, r1.err, r2.err) + note)


async def run_77fuscator(j: Job) -> Result:
    luac = j.work / "77fuscator.luac"
    r = await runner.run([DOTNET, str(F77_DLL), str(j.src), "-o", str(luac), "--strings"],
                         F77_DLL.parent, j.work, j.timeout)
    files = []
    if r.ok and _outfile(luac):
        files.append(("77fuscator.luac", luac))
        src = await _unluac(luac, j)
        if src:
            files.append((src.name, src))
    return Result(bool(files), files, _tail(r.out, r.err))


async def run_ironbrew2(j: Job) -> Result:
    luac = j.work / "ironbrew2.luac"
    r = await runner.run([DOTNET, str(IB2_DLL), str(j.src), str(luac)], TOOLS / "ironbrew2", j.work, j.timeout)
    files = []
    if r.ok and _outfile(luac):
        files.append(("ironbrew2.luac", luac))
        src = await _unluac(luac, j)
        if src:
            files.append((src.name, src))
    return Result(bool(files), files, _tail(r.out, r.err))


# --------------------------------------------------------------------------- Luau-sandbox tools
async def run_luraph(j: Job) -> Result:
    out = j.work / "luraph_deobfuscated.lua"
    r = await runner.run([NODE, "deob.js", str(j.src), "-o", str(out)], TOOLS / "luraph", j.work, j.timeout)
    files = [("luraph_deobfuscated.lua", out)] if _outfile(out) else []
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


def _centurion_missing():
    sb = os.environ.get("CENT_SANDBOX", "")
    if not sb or not (Path(sb) / "harness.py").is_file():
        return "needs the `sandbox-copy-luraph` folder (set CENT_SANDBOX) which was not in the uploaded zip"
    for name in ("luau", "luau-ast", "luau-compile"):
        if not shutil.which(name):
            return "Luau CLI (`%s`) not installed" % name
    return None


async def run_centurion(j: Job) -> Result:
    outdir = j.work / "centurion_out"
    outdir.mkdir(exist_ok=True)
    r = await runner.run([PY, "centurion.py", "deobfuscate", str(j.src), "--out-dir", str(outdir)],
                         TOOLS / "centurion", j.work, j.timeout,
                         env={k: os.environ[k] for k in os.environ if k.startswith("CENT_")})
    files = [(p.name, p) for p in sorted(outdir.glob("*")) if p.is_file() and p.stat().st_size > 0][:5]
    return Result(r.ok and bool(files), files, _tail(r.err, r.out))


async def run_moonveil_static(j: Job) -> Result:
    outdir = j.work / "mv"
    outdir.mkdir(exist_ok=True)
    out = outdir / "moonveil_decompiled.lua"
    r = await runner.run([PY, "moonveil_decompile.py", str(j.src), str(out)], TOOLS / "moonveil", j.work,
                         j.timeout, env={"MOONVEIL_OUT_DIR": str(outdir)})
    names = ["moonveil_structured.lua", "moonveil_decompiled.lua", "moonveil_opcodes.txt", "moonveil_disasm.txt"]
    files = [(n, outdir / n) for n in names if _outfile(outdir / n)]
    log = _tail(r.out, r.err)
    if "could not detect the interpreter" in r.out:
        return Result(False, [], "not a recognised Moonveil build")
    return Result(bool(files), files, log)


TOOL_LIST: List[Tool] = [
    Tool("clyde", "Clyde (V2-V6)", "Static; stack/register VM, debug/normal/max", False,
         [r"clyde", r"clydeprotection", r"clydeprotectionde\.cloud"], run_clyde, _need("node")),
    Tool("prometheus", "Prometheus", "Static; also the WeAreDevs fork", False,
         [r"prometheus", r"wearedevs\.net/obfuscator"], run_prometheus, _need("node")),
    Tool("ironveil", "Ironveil V1", "Static; XOR+LZW bytecode to Lua", False,
         [r"ironveil", r"LeakD discord\.gg"], run_ironveil, _need("node")),
    Tool("hercules", "Hercules", "Static; custom VM + Lua 5.4 payloads", False,
         [r"obfuscated by hercules", r"hercules-obfuscator", r"WrapState\(BcToState", r"WrapState\(", r"BcToState\("],
         run_hercules, lambda: None),
    Tool("moonsec", "MoonSec V3", "Static; devirtualizes to Lua 5.1 bytecode", False,
         [r"moonsec", r"MoonSec_Run", r"MS_V3"], run_moonsec, _dll_missing(MOONSEC_DLL)),
    Tool("77fuscator", "77fuscator 0.6.x", "Static; rebuilds a Lua 5.1 chunk", False,
         [r"77fus", r"77fuscator"], run_77fuscator, _dll_missing(F77_DLL)),
    Tool("ironbrew2", "IronBrew 2", "Static; recovers Lua bytecode", False,
         [r"ironbrew", r"IronBrew2"], run_ironbrew2, _dll_missing(IB2_DLL)),
    Tool("luraph", "Luraph v15", "SANDBOXED; runs script in an offline Luau emulator", True,
         [r"this file was protected using luraph", r"luraph", r"\bLPH_", r"Luraph Script"], run_luraph, _luau_missing, timeout=300),
    Tool("moonveil", "Moonveil (static)", "SANDBOXED; partial output without a trace (see /moonveil)", True,
         [r"moonveil"], run_moonveil_static, _luau_missing, timeout=320),
    Tool("centurion", "Centurion v6/6.1", "SANDBOXED; fake Roblox env + frozen probe packs", True,
         [r"centurion"], run_centurion, _centurion_missing, timeout=300),
]
TOOLS_BY_KEY = {t.key: t for t in TOOL_LIST}

# Tools that carry their own "is this mine?" check and are safe to try blindly (no code execution).
BLIND_ORDER = ["hercules", "clyde", "prometheus", "ironveil", "77fuscator", "moonsec", "ironbrew2"]


def rank(source: str) -> List[Tool]:
    """Tools whose signature appears in the script, best match first."""
    head = source[:300_000]
    scored = []
    for t in TOOL_LIST:
        s = sum(1 for sig in t.sigs if re.search(sig, head, re.I))
        if s:
            scored.append((s, t))
    scored.sort(key=lambda x: -x[0])
    return [t for _, t in scored]


def available(t: Tool) -> Optional[str]:
    return t.check()
