"""Pick a deobfuscator (auto-detect or explicit), run it in a private job dir, return its outputs."""
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from . import registry
from .registry import Job, Result, Tool


@dataclass
class Outcome:
    ok: bool
    tool: Optional[Tool] = None
    files: List[Tuple[str, Path]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    workdir: Optional[Path] = None

    def cleanup(self):
        if self.workdir:
            shutil.rmtree(self.workdir, ignore_errors=True)


async def deobfuscate(data: bytes, tool_key: Optional[str] = None, allow_sandboxed: bool = True) -> Outcome:
    if not data or not data.strip():
        return Outcome(False, notes=["Input script is empty."])

    work = Path(tempfile.mkdtemp(prefix="omni_"))
    text = data.decode("utf-8", "replace")
    out = Outcome(False, workdir=work)

    # ---- explicit tool
    if tool_key and tool_key != "auto":
        tool = registry.TOOLS_BY_KEY.get(tool_key)
        if not tool:
            out.notes.append(f"unknown tool `{tool_key}`")
            return out
        why = registry.available(tool)
        if why:
            out.notes.append(f"**{tool.name}** is unavailable on this host: {why}")
            return out
        src = work / "input.lua"
        src.write_bytes(data)
        res = await tool.run(Job(src, work, forced=True, timeout=tool.timeout))
        return _finish(out, tool, res)

    # ---- auto: signature matches first, then blind-safe static tools
    ranked = registry.rank(text)
    candidates: List[Tool] = []
    for t in ranked:
        if t.sandboxed and not allow_sandboxed:
            continue
        candidates.append(t)
    for key in registry.BLIND_ORDER:
        t = registry.TOOLS_BY_KEY[key]
        if t not in candidates:
            candidates.append(t)

    tried = []
    failed_logs = []
    for t in candidates:
        why = registry.available(t)
        if why:
            if t in ranked:
                out.notes.append(f"looks like **{t.name}**, but it is unavailable here: {why}")
            continue

        # Isolate per-candidate run in its own sub-directory
        cand_work = work / t.key
        cand_work.mkdir(exist_ok=True)
        cand_src = cand_work / "input.lua"
        cand_src.write_bytes(data)

        timeout = t.timeout if t in ranked else min(t.timeout, 90)
        res = await t.run(Job(cand_src, cand_work, forced=False, timeout=timeout))
        tried.append(t.name)

        if res.ok and res.files:
            return _finish(out, t, res)

        # Remember errors for diagnostics
        if res.log and res.log.strip():
            log_snip = res.log.strip()[-500:]
            if t in ranked:
                out.notes.append(f"**{t.name}** matched signature but failed:\n{log_snip}")
            else:
                failed_logs.append((t.name, log_snip))

    if not out.notes and failed_logs:
        # If no signature matched, surface the last failure log for visibility
        last_tool, last_log = failed_logs[-1]
        out.notes.append(f"Last attempt ({last_tool}) failed with:\n{last_log}")

    out.notes.append("no tool could handle this file (tried: %s)" % (", ".join(tried) or "none"))
    return out


def _finish(out: Outcome, tool: Tool, res: Result) -> Outcome:
    out.tool = tool
    out.files = [(n, p) for n, p in res.files if p.exists() and p.stat().st_size > 0]
    out.ok = bool(res.ok and out.files)
    if res.log and res.log.strip():
        out.notes.append(res.log.strip()[-900:])
    return out
