"""Run external deobfuscator processes with a timeout, resource limits and a scrubbed environment.

Obfuscated scripts are untrusted input. Several tools (Luraph, Centurion, Moonveil) execute parts of
them inside a Luau sandbox, so every subprocess gets:
  * no secrets in its environment (DISCORD_TOKEN etc. are never passed down)
  * a hard wall-clock timeout, and the whole process group is killed on expiry
  * CPU-time / memory / file-size rlimits (Linux)
  * captured, size-capped output
"""
import asyncio
import os
import re
import signal
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

MAX_CAPTURE = 200_000  # bytes of stdout/stderr kept per process

_SAFE_ENV_KEYS = (
    "PATH", "LANG", "LC_ALL", "DOTNET_ROOT", "DOTNET_CLI_HOME",
    "NODE_PATH", "LUAU_BIN", "JAVA_HOME", "SYSTEMROOT", "COMSPEC",
    "PREFIX", "ANDROID_ROOT", "ANDROID_DATA", "LD_LIBRARY_PATH"
)

_ANSI = re.compile(r"\x1b\[[0-9;]*m")
_TMP = re.compile(r"([^\s'\"`]+[/\\])?omni_[A-Za-z0-9_]+[/\\]?")


def clean_log(s: str) -> str:
    """Strip ANSI escape sequences and internal server directory paths."""
    if not s:
        return ""
    return _TMP.sub("", _ANSI.sub("", s))


@dataclass
class RunResult:
    code: int
    out: str
    err: str
    timed_out: bool = False

    @property
    def ok(self):
        return self.code == 0 and not self.timed_out


def _limits(mem_mb: int, cpu_s: int, fsize_mb: int):
    def apply():
        try:
            os.setsid()
        except Exception:
            pass
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_s, cpu_s + 5))
            resource.setrlimit(resource.RLIMIT_FSIZE, (fsize_mb << 20, fsize_mb << 20))
            if mem_mb:
                # .NET reserves a lot of virtual address space, so RLIMIT_AS is only applied when asked.
                resource.setrlimit(resource.RLIMIT_AS, (mem_mb << 20, mem_mb << 20))
        except Exception:
            pass
    return apply


def clean_env(workdir: Path, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    env = {k: os.environ[k] for k in _SAFE_ENV_KEYS if k in os.environ}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    
    # Prepend tools/luraph/bin if present so luau can be located seamlessly
    luraph_bin = Path(__file__).resolve().parent.parent / "tools" / "luraph" / "bin"
    if luraph_bin.is_dir():
        env["PATH"] = str(luraph_bin) + os.pathsep + env["PATH"]

    swork = str(workdir)
    env["HOME"] = swork
    env["TMPDIR"] = swork
    env["TEMP"] = swork
    env["TMP"] = swork
    env["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1"
    env["DOTNET_NOLOGO"] = "1"
    env["DOTNET_ROLL_FORWARD"] = "Major"
    env["DOTNET_SYSTEM_GLOBALIZATION_INVARIANT"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    if extra:
        env.update({k: str(v) for k, v in extra.items()})
    return env


async def run(cmd: List[str], cwd: Path, workdir: Path, timeout: int = 120,
              env: Optional[Dict[str, str]] = None, mem_mb: int = 0, fsize_mb: int = 64) -> RunResult:
    kwargs = {}
    prefix = os.environ.get("SANDBOX_PREFIX", "").split()  # e.g. "unshare -rn" or a bwrap command line
    if prefix:
        cmd = prefix + list(cmd)
    if os.name == "posix":
        kwargs["preexec_fn"] = _limits(mem_mb, int(timeout) + 10, fsize_mb)
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, cwd=cwd, env=clean_env(workdir, env),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, **kwargs)
    except FileNotFoundError as e:
        return RunResult(127, "", f"command not found: {e.filename or e}")
    except PermissionError as e:
        return RunResult(126, "", f"permission denied: {e}")
    except OSError as e:
        return RunResult(1, "", f"failed to execute subprocess: {e}")

    timed_out = False
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        timed_out = True
        try:
            if os.name == "posix":
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError, OSError):
                    proc.kill()
            else:
                proc.kill()
        except Exception:
            pass

        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=3.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            out, err = b"", b"process killed after timeout"

    dec = lambda b: (b or b"")[:MAX_CAPTURE].decode("utf-8", "replace")
    return RunResult(proc.returncode if proc.returncode is not None else -9, dec(out), dec(err), timed_out)
